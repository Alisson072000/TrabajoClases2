import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ver-pais',
  templateUrl: './ver-pais.component.html',
  styles: [
  ]
})
export class VerPaisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
